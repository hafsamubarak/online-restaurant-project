<?php 
require './proLogic/proConnection.php';
include './proLogic/helperFunctions.php';
   if($_SESSION['id'] = $_POST['id']){

    header("Location:home.php");

   }



?>